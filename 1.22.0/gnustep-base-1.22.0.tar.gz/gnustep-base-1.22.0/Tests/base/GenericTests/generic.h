
#import <Foundation/NSObject.h>
#import <Foundation/NSString.h>

@interface NSObject(TestsAdditions)
-(BOOL)testEquals: (id)anObject;
-(BOOL)testForString;
-(BOOL)testForClass;
@end

