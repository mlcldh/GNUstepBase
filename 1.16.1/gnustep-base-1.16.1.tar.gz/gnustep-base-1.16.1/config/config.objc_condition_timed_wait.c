
#include <objc/objc.h>
main()
{
	objc_condition_timedwait(NULL,NULL,NULL);
	exit(0);
}

